package com.inventory.test;

import java.util.HashMap;
import java.util.Map;

public class InventoryUtil {
	
	public static Map<String, InventoryPojo> ITEM_MAP = new HashMap<String, InventoryPojo>();
	
	public static Integer CURRENT_COUNTER = 1; 
	
	
	//public static List<InventoryPojo> ITEM_LIST = new ArrayList<InventoryPojo>();
	
	//public static List<InventoryPojo> ITEM_LIST = new ArrayList<InventoryPojo>();
	
	

}
