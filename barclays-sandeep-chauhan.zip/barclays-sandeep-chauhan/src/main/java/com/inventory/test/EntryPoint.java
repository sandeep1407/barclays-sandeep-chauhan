package com.inventory.test;

import java.math.BigDecimal;

public class EntryPoint {

	public static void main(String[] args) {

		String operation = args[0];

		if (operation.equals("create")) {
			InventoryPojo inventoryObj = new InventoryPojo();
			inventoryObj.setItemName(args[1]);
			inventoryObj.setCostPrice(new BigDecimal(args[2]));
			inventoryObj.setSellPrice(new BigDecimal(args[3]));
		}

		if (operation.equals("delete")) {

		}

		if (operation.equals("updateBuy")) {

		}

		if (operation.equals("updateSell")) {

		}

		if (operation.equals("report")) {

		}

	 

	}

}
