package com.inventory.test;

import java.util.List;
import java.util.Map;

public class InventoryOperation {
	
	
public boolean createItem(InventoryPojo inventoryObj){
	boolean status = false;
	try{  
		InventoryUtil.ITEM_MAP.put(inventoryObj.getItemName(), inventoryObj);
		status = true;
	}catch(Exception exp){
		status = false;
	}
	return status;
	
}


public InventoryPojo getItemByName(String name){
	InventoryPojo inventoryPojo = null;
	try{ 
		inventoryPojo = InventoryUtil.ITEM_MAP.get(name); 
	}catch(Exception exp){
		inventoryPojo = null;
	}
	return inventoryPojo;
}

public boolean deleteItem(InventoryPojo inventoryObj){
	boolean status = false;
	try{ 
		InventoryUtil.ITEM_MAP.remove(getItemByName(inventoryObj.getItemName()));
		status = true;
	}catch(Exception exp){
		status = false;
	}
	return status;
}



 



public InventoryPojo updateBuyIncreaseItemQuantity(InventoryPojo inventoryObj){
	InventoryPojo inventoryPojo = null;
	try{ 
		Integer newQnty = inventoryObj.getQuantity();
		inventoryPojo = InventoryUtil.ITEM_MAP.get(inventoryObj.getItemName());
		Integer existQnty = inventoryPojo.getQuantity();
		inventoryPojo.setQuantity((newQnty + existQnty));
		createItem(inventoryPojo);
	}catch(Exception exp){
		inventoryPojo = null;
	}
	return inventoryPojo;
}



public InventoryPojo updateSellItem(InventoryPojo inventoryObj){
	InventoryPojo inventoryPojo = null;
	try{ 
		Integer newQnty = inventoryObj.getQuantity();
		inventoryPojo = InventoryUtil.ITEM_MAP.get(inventoryObj.getItemName());
		Integer existQnty = inventoryPojo.getQuantity();
		inventoryPojo.setQuantity((existQnty - newQnty));
		createItem(inventoryPojo);
	}catch(Exception exp){
		inventoryPojo = null;
	}
	return inventoryPojo;
}


public Map<String, InventoryPojo> report(){ 
	return InventoryUtil.ITEM_MAP; 
} 




}
